﻿using var game = new Project1_OOP.Game1();
game.Run();




